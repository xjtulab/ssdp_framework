#include <uxr/client/client.h>

int main()
{
    return 0;
}