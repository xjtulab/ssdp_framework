# ShapesDemo
Please see the [ShapesDemo manual](http://micro-xrce-dds.readthedocs.io/en/latest/shapes_demo.html)
